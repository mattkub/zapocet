public interface CisloVCisle {

	/**
	 * Metoda zrata pocet cisel v inom cisle
	 * @param hladaneCislo hladane cislo - nezáporné, jednomieste!
	 * @param cislo cislo v ktorom sa hlada - nezáporné
	 * @return
	 */
	public int zrataj(int hladaneCislo, int cislo);
}
